import React from 'react';
import './App.css';
import {
  HashRouter as Router,
  Route,
  NavLink
} from 'react-router-dom';


class Home extends React.Component 
{  
  render () 
  {      
    return ( <p>This is the Home Page for my Assignment</p> );
  }    
};

class About extends React.Component 
{  
  render () 
  {      
    return ( <p>This is the About Page for my Assignment</p> );
  }    
};

class Contact extends React.Component 
{  
  render () 
  {      
    return ( <p>This is the Contact Page for my Assignment</p> );
  }    
};

class TodoList extends React.Component {

  constructor(props) 
  {
    super(props);
    this.state = 
    { 
      toshow: "",
      input: "",
	  items: 
        [
          {task: 1, duty: "Walk the dog"},
          {task: 2, duty: "Pick up Laundry"},
          {task: 3, duty: "Do grocery shopping"}
        ], 
	  id: 3,
	  editItem: false 
    }
 }
 
  inputStateChange(event) {
    this.setState({input: event.target.value});
  }
 
 
 submitFunc() {
	 const newItem = {
	 task: this.state.id += 1,
	 duty: this.state.input
	 }

	 const UpdatedItems = [...this.state.items, newItem];
	 
    this.setState({
	  items: UpdatedItems,
      toshow: this.state.input,
      input: "",
	  editItem: false,

    });
  }
  
 deleteFunc = (id) => {
	 const filteredItems = this.state.items.filter(item =>
	 item.task !== id);
	 this.setState({
		 items: filteredItems
	 });
  }
  
 editFunc = (id) => {
	 const filteredItems = this.state.items.filter(item =>
	 item.task !== id);
	 
	 const selectedItem = this.state.items.find(item =>
	 item.task === id);
	 
	 this.setState({
		 items: filteredItems,
		 input: selectedItem.duty,
		 editItem: true,
		 task: selectedItem.task
	 });
  }

 // The key is a unique identifier that helps React 
 // to manage changes that occur to the list!
 renderList({task, duty}) { 
   return <tr><td key={task}>{duty}</td><button onClick={() => this.deleteFunc(task)}>D</button>
										<button onClick={() => this.editFunc(task)}>E</button></tr>;
 }

 render() {
   return (
     <div>
       <h2>To Do List</h2>
	   <input type="text" onChange={this.inputStateChange.bind(this)}
           value={this.state.input} />
       <button onClick={this.submitFunc.bind(this)}>{this.state.editItem ? "Edit" : "Add"}</button><br/><br/>
	   <table>
          <tbody>
             {this.state.items.map(this.renderList.bind(this))}
		  </tbody>
        </table>
     </div>
   );
 }

};

class App extends React.Component 
{
  render ()
  {
    return (

      <Router>
        <div>
          <h1>Assignment 10</h1>
          <ul>
            {
              // Our NavLinks create navigiation links that React Router 
              // will associate with our routes.  NavLinks will use the 
              // active css class to style themselves when they are the 
              // active link.  See the active css class in App.css.  We
              // need to use the exact property for our root/home path 
              // otherwise home will always be considered active.
            }
            <li><NavLink exact to="/">Home</NavLink></li>
            <li><NavLink to="/TODO">TODO</NavLink></li>
            <li><NavLink to="/contact">Contact</NavLink></li>			
			<li><NavLink to="/about">About</NavLink></li>
          </ul>

          <hr/>
  
          {
            // Render a different component depending on the path, "/" is the 
            // "no path" case.  We add the property exact to have it render 
            // only on exact matches, otherwise "/" would also match for 
            // things like "/about".
          } 
          <Route exact path="/" component={Home}/>
          <Route path="/TODO" component={TodoList}/>          
		  <Route path="/contact" component={Contact}/>
		  <Route path="/about" component={About}/>
          
        </div>
      </Router>
    );
  }
}

export default App;
