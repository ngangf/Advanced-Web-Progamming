const axios = require('axios');

async function test()
{
  try {
  
	// make a request to our server, send JSON data in the request
    const response1 = await axios.post('http://localhost:3000/api',
	                                  {"item": "fish", "description": "very orange", "price": "1"});
									  
	// response body is JSON object .data
	console.log(response1.data);
	
	// send another post request
    const response2 = await axios.post('http://localhost:3000/api',
	                                  {"item": "cats", "description": "large eyes", "price": "15"});
	console.log(response2.data);
	
	// send another post request
    const response3 = await axios.post('http://localhost:3000/api',
	                                  {"item": "pigs", "description": "very dirty", "price": "75"});
	console.log(response3.data);
	
	// send another post request
    const response4 = await axios.post('http://localhost:3000/api',
	                                  {"item": "snakes", "description": "very long", "price": "125"});
	console.log(response4.data);
	
	// make a delete request
    const response5 = await axios.delete('http://localhost:3000/api/7');

	console.log(response5.data);
	
	// make a get request to check the results
    const response6 = await axios.get('http://localhost:3000/api');

	console.log(response6.data);
  
  } catch (error) {
    console.error(error);
  }	
}

// call our test function
test();
