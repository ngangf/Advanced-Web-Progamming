var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("restapi.db");
var express = require('express');
var app = express();

// use JSON middleware to parse request bodies and put result into req.body
app.use(express.json());

// startup a collection of data to manage
db.serialize(function(){

  // create a fresh version of the table
  db.run("DROP TABLE IF EXISTS Collection");
  db.run("CREATE TABLE Collection (item TEXT, description TEXT, " +
  	     "price INTEGER)");

  // insert initial records into the table
  var stmt = db.prepare("INSERT INTO Collection VALUES (?,?,?)");
  stmt.run("Dog", "Wags tail when happy", "250");
  stmt.run("Rabbit", "Likes to eat carrots", "50");
  stmt.run("Hamster", "Likes to eat lettuce", "5");
  stmt.finalize();

});

// GET the entire collection, send it back as JSON data
app.get("/api",
  function(req,res)
  {
    console.log("GET REQUEST RECEIVED");

  	db.all("SELECT rowid as id, item, description, price FROM Collection",
  		   function(err, results)
  		   {
			 // send back table data as JSON data
             res.json(results);
  		   });
  });

// GET a specific item in the collection, send it back as JSON data
app.get("/api/:id",
  function(req,res)
  {
  	console.log("GET REQUEST FOR SPECIFIC ITEM  RECEIVED");
	
	db.all("SELECT * FROM Collection WHERE rowid=(?)",(req.params.id),
  		   function(err, results)
  		   {
             // send back table data as JSON data
             res.json(results);
  		   });
});

// PUT request to replace the entire collection
app.put("/api",
  function(req,res)
  {
  	console.log("PUT REQUEST RECEIVED");

    // make the update to the database
    db.serialize(function() {
	  db.run("DELETE FROM Collection");
      var stmt = db.prepare("INSERT INTO Collection VALUES (?,?,?), (?,?,?), (?,?,?)");
        stmt.run((req.body[0].item), (req.body[0].description), (req.body[0].price),
				 (req.body[1].item), (req.body[1].description), (req.body[1].price),
				 (req.body[2].item), (req.body[2].description), (req.body[2].price),
               // only send the response when we know the I/O has completed
               function()
               {
                 res.json({response: "COLLECTION UPDATED"});
               }
               );

      stmt.finalize();
    });
});

// PUT request to change a specific item in the collection
app.put("/api/:id",
  function(req,res)
  {
  	console.log("PUT REQUEST FOR SPECIFIC ITEM RECEIVED");

    // make the update to the database
    db.serialize(function() {
      var stmt = db.prepare("UPDATE Collection set item=(?), " +
      	                    "description=(?), price=(?) WHERE " +
      	                    "rowid=(?)");
      stmt.run(req.body.item,
        	     req.body.description,
        	     req.body.price,
               req.params.id,
               // only send the response when we know the I/O has completed
               function()
               {
                 res.json({response: "ITEM UPDATED"});
               }
               );

      stmt.finalize();
    });
});

// DELETE the entire collection
app.delete("/api",
  function(req,res)
  {
  	console.log("DELETE REQUEST RECEIVED");

    db.run("DELETE FROM Collection",
           function()
           {
             res.json({response: "COLLECTION DELETED"});
           });
  });
  
// DELETE a specific item in the collection
app.delete("/api/:id",
  function(req,res)
  {
  	console.log("DELETE REQUEST FOR SPECIFIC ITEM  RECEIVED");

    db.run("DELETE FROM Collection WHERE " + "rowid=(?)", (req.params.id),
           function()
           {
             res.json({response: "ITEM DELETED"});
           });
  });
  
// INSERT an item into the collection
app.post("/api",
  function(req,res)
  {
  	console.log("POST REQUEST RECEIVED");
	//console.log("JSON DATA: " + JSON.stringify(req.body));
    db.run("INSERT INTO Collection VALUES (?,?,?)", (req.body.item), (req.body.description), (req.body.price),
           function()
           {
             res.json({response: "ITEM INSERTED"});
           });
  });

var server = app.listen(3000, function(){
  console.log("RESTful API listening on port 3000!")
});