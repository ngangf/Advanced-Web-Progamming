const express = require('express');
var router = express.Router()

// Displays the login page
router.get("/sign-up", function(req, res)
{
  // if we had an error during form submit, display it, clear it from session
  req.TPL.login_error = req.session.login_error;
  req.session.login_error = "";

  // render the login page
  res.render("sign-up", req.TPL);
});

// Attempts to sign-up a user
// - The action for the form sign-up on the login page.
router.post("/sign-up", function(req, res)
{
	// is the username and password OK?
	if (req.body.username !== "" &&
      req.body.password !== "")
	{
    // set a session key username to login the user
    req.session.username = req.body.username;

    // re-direct the logged-in user to the editors page
    res.redirect("/users");
  }
  else
  {
    // if we have an error, reload the login page with an error
    req.session.login_error = "Invalid username and/or password!";
    res.redirect("/sign-up");
  }
});

module.exports = router;