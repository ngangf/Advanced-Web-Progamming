const express = require('express');
var router = express.Router()
const ArticlesModel = require('../models/articles.js')

// Displays the login page
router.get("/", function(req, res)
{
  // if we had an error during form submit, display it, clear it from session
  req.TPL.login_error = req.session.login_error;
  req.session.login_error = "";

  // render the login page
  res.render("login", req.TPL);
});

// Attempts to login a user
// - The action for the form submit on the login page.
router.post("/attemptlogin", function(req, res)
{

  // is the username and password OK? (Mem1)
  if (req.body.username == "mem1" && req.body.password == "mem1")
  {
    // set a session key username to login the user
    req.session.username = req.body.username;

    // re-direct the logged-in user to the members page
    res.redirect("/members");
  }
  // is the username and password OK? (Mem2)
  else if (req.body.username == "mem2" && req.body.password == "mem2")
  {
    // set a session key username to login the user
    req.session.username = req.body.username;

    // re-direct the logged-in user to the members page
    res.redirect("/members");
  }
  
  // is the username and password OK? (Edit1)
	else if (req.body.username == "edit1" && req.body.password == "edit1")
  {
    // set a session key username to login the user
    req.session.username = req.body.username;

    // re-direct the logged-in user to the editors page
    res.redirect("/editors");
  }
  // is the username and password OK? (Edit2)
  else if (req.body.username == "edit2" && req.body.password == "edit2")
  {
    // set a session key username to login the user
    req.session.username = req.body.username;

    // re-direct the logged-in user to the editors page
    res.redirect("/editors");
  }
  else
  {
    // if we have an error, reload the login page with an error
    req.session.login_error = "Invalid username and/or password!";
    res.redirect("/login");
  }

});

// Logout a user
// - Destroys the session key username that is used to determine if a user
// is logged in, re-directs them to the home page.
router.get("/logout", function(req, res)
{
  delete(req.session.username);
  res.redirect("/home");
});

module.exports = router;
