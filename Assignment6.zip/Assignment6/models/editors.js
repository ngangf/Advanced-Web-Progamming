var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("Users.db");

// select all the users, call the callback with them as a parameter
function getAllUsers(callback)
{
  db.all("SELECT rowid, * FROM Users",
         function(err,results) { callback(results); });
}

// delete an employee with a given id
function deleteUser(id,callback)
{
  db.run("DELETE FROM Users WHERE rowid=?", id,
         function(err) { callback(); });
}

// export the functions we have defined
module.exports = {getAllUsers, deleteUser};
