var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("employee.db");

// select all the employees, call the callback with them as a parameter
function getAllEmployees(callback)
{
  db.all("SELECT rowid, * FROM Employees",
         function(err,results) { callback(results); });
}

// delete an employee with a given id
function deleteEmployee(id,callback)
{
  db.run("DELETE FROM Employees WHERE rowid=?", id,
         function(err) { callback(); });
}

// insert an employee into the table
function addEmployee(employee,callback)
{
  db.run("INSERT INTO Employees VALUES (?,?,?,?)",
         [employee.firstname, employee.lastname, employee.salary, employee.role],
         function(err) { callback(); });
}

// insert a random employee into the table
function randomEmployee(callback)
{
  var names = ["Jack","Peter","Liz","Jane"];
  var roles = ["Tester","Developer","Manager"];
  var min = 10000;
  var max = 100000;
  db.run("INSERT INTO Employees VALUES (?,?,?,?)",
         [names[Math.floor(Math.random()*names.length)], 
		 names[Math.floor(Math.random()*names.length)], 
		 Math.floor(Math.random() * (max - min + 1)), 
		 roles[Math.floor(Math.random()*roles.length)]],
         function(err) { callback(); });
}

// update an employee with a given id
function updateEmployee(employee,id,callback)
{
  db.run("UPDATE Employees SET firstname=?,lastname=?,salary=?,role=? WHERE rowid=?",
         [employee.firstname, employee.lastname, employee.salary, employee.role, id],
         function(err) { callback(); });
}

// promote an employee with a given id
function promoteEmployee(id,callback)
{
  db.run("UPDATE Employees SET role='Manager' WHERE rowid=?", id,
          function(err) { callback(); });
}

// layoff an employee with a given role
function layoffEmployee(callback)
{
  db.run("DELETE FROM Employees WHERE role='Developer' OR role='Tester'",
         function(err,results) { callback(); });
}

//sort the firstname column in ascending order
function sortFirstnameAsc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY firstname asc",
		 
		 function(err, results) {callback(results)});
}

//sort the firstname column in descending order
function sortFirstnameDesc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY firstname desc",
		 
		 function(err, results) {callback(results)});
}

//sort the lastname column in ascending order
function sortLastnameAsc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY lastname asc",
		 
		 function(err, results) {callback(results)});
}

//sort the lastname column in descending order
function sortLastnameDesc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY lastname desc",
		 
		 function(err, results) {callback(results)});
}

//sort the salary column in ascending order
function sortSalaryAsc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY salary asc",
		 
		 function(err, results) {callback(results)});
}

//sort the salary column in descending order
function sortSalaryDesc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY salary desc",
		 
		 function(err, results) {callback(results)});
}

//sort the id column in ascending order
function sortIdAsc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY rowid asc",
		 
		 function(err, results) {callback(results)});
}

//sort the id column in descending order
function sortIdDesc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY rowid desc",
		 
		 function(err, results) {callback(results)});
}

//sort the role column in ascending order
function sortRoleAsc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY role asc",
		 
		 function(err, results) {callback(results)});
}

//sort the role column in ascending order
function sortRoleDesc(callback)
{
  db.all("SELECT rowid, * FROM Employees ORDER BY role desc",
		 
		 function(err, results) {callback(results)});
}

// export the functions we have defined
module.exports = {getAllEmployees, deleteEmployee, addEmployee, updateEmployee, promoteEmployee, layoffEmployee, sortFirstnameAsc, sortFirstnameDesc, sortLastnameAsc, sortLastnameDesc, 
				  randomEmployee, sortSalaryAsc, sortSalaryDesc, sortIdAsc, sortIdDesc, sortRoleAsc, sortRoleDesc};
