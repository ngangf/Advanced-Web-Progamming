// include express
const express = require('express');
const app = express();

// include the mustache template engine for express
const mustacheExpress = require('mustache-express');

// include the model so the controller can use its functions
const Model = require('./app.model.js')

// registers the mustache engine with express
app.engine("mustache", mustacheExpress());

// sets mustache to be the view engine
app.set('view engine', 'mustache');

// sets /views to be the /views folder
// files should have the extension filename.mustache
app.set('views', __dirname + '/views');

// ************************* CONTROLLER ACTIONS ****************************

// delete an employee action (given an id parameter)
app.get('/delete/:id', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. delete the employee first, then get all the employees
  Model.deleteEmployee(req.params.id, getEmployees);

});

// addform action puts the add employee form on the page
app.get('/addform', function(req,res) {

  // 2. render the page with the employee data AND display the add form
  function renderPage(employeeArray)
  {
    res.render('main_page', {addemployee: true, employees: employeeArray});
  }

  // 1. get all the employees, then render the page
  Model.getAllEmployees(renderPage);

});

// addemployee action handles add form submit, inserts new employee into table
app.get('/addemployee', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. Insert employee into table using form data, then get all the employees
  Model.addEmployee(req.query, getEmployees);

});

// randomemployee action handles add form submit, inserts new random employee into table
app.get('/randomemployee', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. Insert employee into table using form data, then get all the employees
  Model.randomEmployee(getEmployees);

});

// updateform action puts the update employee form on the page
app.get('/updateform/:id', function(req,res) {

  // 2. render the page with the employee data AND display update form
  function renderPage(employeeArray)
  {
    // filter the employeeArray for the employee with the id parameter, that's
    // the employee that we want to populate the form with (see: formdata)
    res.render('main_page',
      {updateemployee: true
      ,updateid: req.params.id
      ,formdata : employeeArray.filter(x => (x.rowid == req.params.id))[0]
      ,employees: employeeArray
      });
  }

  // 1. get all the employees, then render the page
  Model.getAllEmployees(renderPage);

});

// updateemployee action handles updating the employee in the database
app.get('/updateemployee/:id', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. update the employee in the database, then get all the employees
  Model.updateEmployee(req.query, req.params.id, getEmployees);

});

// promoteemployee action handles updating the employee in the database
app.get('/promoteemployee/:id', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. update the employee in the database, then get all the employees
  Model.promoteEmployee(req.params.id, getEmployees);

});

// layoff action handles updating the employee in the database
app.get('/layoffemployee', function(req,res) {

  // 3. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 2. Get all the employees, then render the page
  function getEmployees() { Model.getAllEmployees(renderPage); }

  // 1. update the employee in the database, then get all the employees
  Model.layoffEmployee(getEmployees);

});

// default action: render the page with employee data
app.get('/', function(req,res) {

  // 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

  // 1. get all the employees, then render the page
  Model.getAllEmployees(renderPage);

});

//sort the firstname column in ascending order
app.get("/sort_firstname_asc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the First Name column, then render the page
  Model.sortFirstnameAsc(renderPage);
  
});

//sort the firstname column in descending order
app.get("/sort_firstname_desc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the First Name column, then render the page
  Model.sortFirstnameDesc(renderPage);
  
});

//sort the lastname column in ascending order
app.get("/sort_lastname_asc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the Last Name column, then render the page
  Model.sortLastnameAsc(renderPage);
  
});

//sort the Last name column in descending order
app.get("/sort_lastname_desc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the Last Name column, then render the page
  Model.sortLastnameDesc(renderPage);

});

//sort the salary column in ascending order
app.get("/sort_salary_asc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the Salary Name column, then render the page
  Model.sortSalaryAsc(renderPage);
  
});

//sort the salary column in descending order
app.get("/sort_salary_desc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the salary column, then render the page
  Model.sortSalaryDesc(renderPage);
  
});

//sort the id column in ascending order
app.get("/sort_id_asc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the id column, then render the page
  Model.sortIdAsc(renderPage);
  
});

//sort the id column in descending order
app.get("/sort_id_desc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the id column, then render the page
  Model.sortIdDesc(renderPage);
  
});

//sort the role column in ascending order
app.get("/sort_role_asc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the role column, then render the page
  Model.sortRoleAsc(renderPage);
  
});

//sort the role column in descending order
app.get("/sort_role_desc", function(req,res){
	
// 2. render the page with the employee data
  function renderPage(employeeArray) {
    res.render('main_page', { employees: employeeArray});
  }

// 1. sort the role column, then render the page
  Model.sortRoleDesc(renderPage);
  
});

// catch-all router case intended for static files
app.get(/^(.+)$/, function(req,res) {
  res.sendFile(__dirname + req.params[0]);
});

app.listen(8081, function() { console.log("server listening..."); } );
