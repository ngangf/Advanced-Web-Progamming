// Required packages
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

// Return the auction page
app.get('/auction', function(req,res){
  res.sendFile(__dirname + '/auction.html');
});

// Return the bidder page
app.get('/bidder', function(req,res){
  res.sendFile(__dirname + '/bidder.html');
});

// If we have a connection....
io.on('connection', function(socket){
	
  socket.on("submitauction", function(auctiondata)
  {

    // Set the bid price and item description
    bidprice = auctiondata.price;
	item = auctiondata.description;
	name = auctiondata.name;

    // Make sure we've received the question OK
    console.log(item);
	console.log(bidprice);
	console.log(name);
	console.log("Auction submitted: " + JSON.stringify(auctiondata));
   
    // Broadcast the item description and starting bid price to all the bidders
    socket.broadcast.emit("deliverauction", auctiondata.description, auctiondata.price, auctiondata.name);

  }); 
  
  socket.on("newbid", function(namedata, pricedata){

  // Send back the updated bid
    io.emit("resultauction",
    	    {correct: (pricedata > bidprice),
    	     newprice: pricedata,
			 newname: namedata,
			 newitem: item});
  });
  
});
  
// Start the server
http.listen(3000, function(){
  console.log('listening on *:3000');
});