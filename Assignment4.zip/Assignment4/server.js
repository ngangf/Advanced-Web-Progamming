const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

app.get('/', function(req, res)
{
  res.sendFile(__dirname + "/form.html")
});

function getRandom(min, max) {
  return Math.floor(Math.random() * (max-min+1)) + min;
}

app.get('/random', function(req, res)
{
  // possible random first names
  const firstname = ["Kevin", "John", "Sally", "Larissa",
                     "Zhang", "Li", "Ying", "Wang",
                     "Nayla", "Nawal", "Abdul", "Yasin"];

  // possible random last names
  const lastname = ["Browne", "Black", "Smith", "Yendt",
                    "Wei", "Fang", "Patel", "Lee",
                    "Abaza", "Shadid", "Hatem", "Hassin"];

  // random generation of tuition
  const tuition = getRandom(7956, 2800);

  // random generation of a student id
  const studentid =
    "0" + getRandom(0, 9) + getRandom(0,9) + getRandom(0,9) + getRandom(0,9) +
    getRandom(0,9) + getRandom(0,9) + getRandom(0,9) + getRandom(0,9);

  // possible payment methods
  const paymentmethods = ["Credit", "Debit", "Bitcoin"];

  // create random student based on arrays, randomness
  const student =
    {
      "firstname" : firstname[getRandom(0, (firstname.length - 1))],
      "lastname" : lastname[getRandom(0, (lastname.length - 1))],
      "tuition" : tuition,
      "studentid" : studentid,
      "method" : paymentmethods[getRandom(0, (paymentmethods.length - 1))]
    };

  // send the json data as the response
  res.json(student);

});

app.get("/submit", function(req,res){
	
	var resobj = {};
	
	
	if (req.query.FName.length >= 2)
	{
		resobj.FName = "<li>First Name verified OK</li><br/>";
	}
	else resobj.FName = "<li>First Name must be 2 or more characters in length</li><br/>"
	
	if (req.query.LName.length <= 3)  
	{
		resobj.LName = "<li>Last Name must be between 3 and 12 characters in length</li><br/>";
	}
	else if ( req.query.LName.length <= 12)
		{
		resobj.LName = "<li>Last Name verified OK</li><br/>";
		}
	else resobj.LName = "<li>Last Name must be between 3 and 12 characters in length</li><br/>"
	
	if (req.query.StID.length === 9)
	{
		resobj.StID = "<li>Student ID verified OK</li><br/>";
	}
	else resobj.StID = "<li>Student ID must be exactly 9 characters in length</li><br/>"
	
	if (parseInt(req.query.Tuition) < 2000)  
	{
		resobj.Tuition = "<li>Tuition must be between 2000 and 10000</li><br/>";
	}
	else if ( parseInt(req.query.Tuition) <= 10000)
		{
		resobj.Tuition = "<li>Tuition verified OK</li><br/>";
		}
	else resobj.Tuition = "<li>Tuition must be between 2000 and 10000</li><br/>"  
	
	res.json(resobj);
});

fs.appendFile('log.txt', 'data to append' + ", ", function (err) {
  if (err) throw err;
  console.log('Saved!');
});

app.listen(3000, () => console.log(`Example app listening on port ${port}!`));
