// This code will only work if its used inside a Twilio function as 
// show in the notes and discussed in-class.

// Include the necessary packages
const https = require('https');
var redis = require("redis");

// connection to the service using our url, password 
// change this to use your URL and password
client = 
  redis.createClient(
     {url: "redis://redis-16798.c44.us-east-1-2.ec2.cloud.redislabs.com:16798"
     ,password: "miPghvc9SPocZgPKLTW5pgO6am1STQYP"
     }
  );
  

// does a get command on a redis database...
function reqRedisGet(key)
{
    return new Promise(function(resolve) {
       function callback(err, reply)
       {
           resolve(reply);
       }
       client.get(key, callback);  
    });
}

// does a set command on a redis database...
function reqRedisSet(key,val)
{
    return new Promise(function(resolve) {
       function callback(err, reply)
       {
           resolve(reply);
       }
       client.set(key,val, callback);  
    });
}

// Will request an external api for us... uses a parameter in the path
// - See api details: https://reststop.randomhouse.com/
function reqapi(message) 
{

  // options for the request
  var options = 
  {
     port: '443',
     method: 'GET',
     hostname: "reststop.randomhouse.com",
     path: "/resources/authors/" + message 
  };

  return new Promise(function(resolve) {

    callback1 = function(response)
    {
      var str = ""; 
      response.on('data', function(chunk) { str += chunk; });
      response.on('end', function () { 
        resolve(str);
      });
    };

    // make the request
    https.request(options,callback1).end();

  });
}

function reqapi2(message) 
{

  // options for the request
  var options = 
  {
     port: '443',
     method: 'GET',
     hostname: "reststop.randomhouse.com",
     path: "/resources/authorevents/" + message 
  };

  return new Promise(function(resolve) {

    callback1 = function(response)
    {
      var str = ""; 
      response.on('data', function(chunk) { str += chunk; });
      response.on('end', function () { 
        resolve(str);
      });
    };

    // make the request
    https.request(options,callback1).end();

  });
}

exports.handler = async function(context, event, callback) {
	
  let twiml = new Twilio.twiml.MessagingResponse();
  
  var eventBody = event.Body;
  var command = eventBody.split(" ");

  if (command[1] == "author")
  {
    const apiResponse = await reqapi(command[2]);
    twiml.message("api response: \n" + apiResponse);
  }
  
  else if (command[1] == "event")
  {
    const apiResponse2 = await reqapi2(command[2]);
    twiml.message("api event response: \n" + apiResponse2);
  }
  
  else if (command[0] == "Deposit")
  {
    const redisSet = await reqRedisSet(command[3], command[1]);
    twiml.message("redis set response: " + redisSet);
  }
  
  else if (command[0] == "Balance")
  {
    const redisGet = await reqRedisGet(command[1]);
    twiml.message("redis get response: " + redisGet);
  }
  
  else
  {
      twiml.message("About: This bot searches for authors and their events based on an id. " + 
                    "It also allows users to deposit and view the balance of their accounts");
  }
  // sends back the message
  callback(null, twiml);    

};